package ProyectoFinal.ClinicaOdontologica;

import org.junit.jupiter.api.Test;

class PacienteServiceTest {

    @Test
    void guardarPaciente() {
    }

    @Test
    void listarPacientes() {
    }

    @Test
    void buscarPacientePorEmail() {
    }

    @Test
    void buscarPacientePorId() {
    }

    @Test
    void actualizarPaciente() {
    }

    @Test
    void eliminarPaciente() {
    }
}