package ProyectoFinal.ClinicaOdontologica.entities;

public enum UserRole {
    ROLE_USER, ROLE_ADMIN
}
